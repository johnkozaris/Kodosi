//! Utility package for miscellaneous functions.
const std = @import("std");

const colorpkg = @import("../color.zig");

const Point = @import("Point.zig");

const vector_length = @import("../z2d.zig").vector_length;

/// Internal table test helper. Passes in an array of structs representing test
/// cases. "name" is the only expected field, otherwise it's entirely handled
/// by `f`.
pub fn runCases(name: []const u8, cases: anytype, comptime f: *const fn (case: anytype) TestingError!void) !void {
    for (cases) |tc| {
        f(tc) catch |err| {
            std.debug.print("FAIL: {s}/{s}\n", .{ name, tc.name });
            return err;
        };
    }
}

/// Error union for `runCases`' test function. Must accommodate all of the
/// appropriate errors from the testing package in use.
pub const TestingError = error{
    TestUnexpectedError, // Use as placeholder for unexpected errors

    TestExpectedEqual,
    TestExpectedApproxEqAbs,
    TestUnexpectedResult,
    InvalidMatrix, // Transformation.Error.InvalidMatrix
    OutOfMemory, // std.mem.Allocator.Error
};

/// Internal vectorization function. Turns each field into a
/// `@Vector(vector_length, T)`, to allow for SIMD and ease of utilization by
/// the compositor.
pub fn vectorize(comptime T: type) type {
    const info = @typeInfo(T).@"struct";
    const num = info.field_names.len;
    var field_types: [num]type = undefined;
    var field_attrs: [num]std.lang.Type.Struct.FieldAttributes = undefined;
    for (info.field_types, 0..) |f_type, i| {
        field_types[i] = @Vector(vector_length, f_type);
        field_attrs[i] = .{
            .@"comptime" = false,
            .@"align" = @alignOf(field_types[i]),
            .default_value_ptr = null,
        };
    }
    return @Struct(.auto, null, info.field_names, &field_types, &field_attrs);
}

/// Internal function for splatting, shorthand for
/// `@as(@Vector(vector_length, T), @splat(value))`.
pub fn splat(comptime T: type, value: anytype) @Vector(vector_length, T) {
    return @splat(value);
}

/// Internal function for vector gather, allows for array lookup via an index
/// of vectors.
///
/// Based on https://github.com/ziglang/zig/issues/12815#issuecomment-1243043038
pub fn gather(slice: anytype, index: anytype) @Vector(
    @typeInfo(@TypeOf(index)).vector.len,
    @typeInfo(@TypeOf(slice)).pointer.child,
) {
    const vector_len = @typeInfo(@TypeOf(index)).vector.len;
    const Elem = @typeInfo(@TypeOf(slice)).pointer.child;
    var result: [vector_len]Elem = undefined;
    comptime var vec_i = 0;
    inline while (vec_i < vector_len) : (vec_i += 1) {
        result[vec_i] = slice[index[vec_i]];
    }
    return result;
}

/// Short-hand splatted f32 zero values, used in multiple places.
pub const zero_float_vec = splat(f32, 0.0);

/// Short-hand splatted color zero values, used in multiple places.
pub const zero_color_vec: [vector_length]colorpkg.Color = zero_color_vec: {
    var result: [vector_length]colorpkg.Color = undefined;
    for (0..vector_length) |i| {
        result[i] = colorpkg.LinearRGB.init(0, 0, 0, 0).asColor();
    }
    break :zero_color_vec result;
};

/// Returns `true` if the field `name` exists in the supplied type. `T` must be
/// a struct.
pub fn hasField(comptime T: type, field_name: []const u8) bool {
    inline for (@typeInfo(T).@"struct".field_names) |f_name| {
        if (std.mem.eql(u8, f_name, field_name)) {
            return true;
        }
    }
    return false;
}

/// Pulled from old stdlib as this function has been removed.
pub fn readerInt(reader: *std.Io.Reader, comptime T: type, endian: std.lang.Endian) std.Io.Reader.Error!T {
    const bytes = try readerBytesNoEof(reader, @divExact(@typeInfo(T).int.bits, 8));
    return std.mem.readInt(T, &bytes, endian);
}

/// Pulled from old stdlib as this function has been removed.
pub fn readerByteSigned(reader: *std.Io.Reader) std.Io.Reader.Error!i8 {
    return @as(i8, @bitCast(try readerByte(reader)));
}

/// Pulled from old stdlib as this function has been removed.
pub fn readerByte(reader: *std.Io.Reader) std.Io.Reader.Error!u8 {
    var result: [1]u8 = undefined;
    try reader.readSliceAll(&result);
    return result[0];
}

/// Pulled from old stdlib as this function has been removed.
pub fn readerSkipBytes(reader: *std.Io.Reader, num_bytes: u64) std.Io.Reader.Error!void {
    const buf_size = 512;

    var buf: [buf_size]u8 = undefined;
    var remaining = num_bytes;

    while (remaining > 0) {
        const amt = @min(remaining, buf_size);
        try reader.readSliceAll(buf[0..amt]);
        remaining -= amt;
    }
}

/// Pulled from old stdlib as this function has been removed.
fn readerBytesNoEof(reader: *std.Io.Reader, comptime num_bytes: usize) std.Io.Reader.Error![num_bytes]u8 {
    var bytes: [num_bytes]u8 = undefined;
    try reader.readSliceAll(&bytes);
    return bytes;
}

/// Changes the seek position of the supplied reader, returning an error if it is past the end.
pub fn readerSeek(reader: *std.Io.Reader, seek: usize) error{InvalidSeek}!void {
    if (seek > reader.end) return error.InvalidSeek;
    reader.seek = seek;
}
